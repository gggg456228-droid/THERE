THERE Windows update payload.
Keep your existing installation folder. THERE.exe applies newer payloads automatically on startup.
User data is stored outside the application folder under %LOCALAPPDATA%\THERE\data.
