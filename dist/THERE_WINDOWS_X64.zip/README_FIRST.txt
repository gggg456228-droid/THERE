THERE Windows update payload.
This is an in-place patch for an existing THERE installation.
The updater copies these files over the installed application and preserves the rest of runtime and user data.
User data is stored outside the application folder under %LOCALAPPDATA%\THERE\data.
